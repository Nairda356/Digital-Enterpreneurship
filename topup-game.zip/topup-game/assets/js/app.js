(function () {
  'use strict';
  var rupiah = function (n) { return 'Rp ' + Number(n).toLocaleString('id-ID'); };

  // Cari game di beranda
  var cari = document.getElementById('cari-game');
  if (cari) {
    var tiles = document.querySelectorAll('#game-grid .game-tile');
    var kosong = document.getElementById('game-kosong');
    cari.addEventListener('input', function () {
      var q = cari.value.trim().toLowerCase(), tampil = 0;
      tiles.forEach(function (t) {
        var cocok = t.dataset.nama.indexOf(q) !== -1;
        t.hidden = !cocok;
        if (cocok) tampil++;
      });
      kosong.hidden = tampil > 0;
    });
  }

  // Ringkasan harga di form pesanan (hanya tampilan; server menghitung ulang dari database)
  var form = document.getElementById('form-order');
  if (form) {
    var el = function (id) { return document.getElementById(id); };
    var update = function () {
      var p = form.querySelector('input[name="produk"]:checked');
      var m = form.querySelector('input[name="metode"]:checked');
      var harga = p ? Number(p.dataset.harga) : 0;
      var biaya = m ? Number(m.dataset.biaya) : 0;
      el('s-item').textContent = p ? p.dataset.nama : 'Belum dipilih';
      el('s-harga').textContent = p ? rupiah(harga) : '-';
      el('s-metode').textContent = m ? m.dataset.nama : 'Belum dipilih';
      el('s-biaya').textContent = m ? rupiah(biaya) : '-';
      el('s-total').textContent = rupiah(harga + biaya);
    };
    form.addEventListener('change', update);
    update();
  }

  // Konfirmasi sebelum aksi berisiko
  document.addEventListener('click', function (ev) {
    var b = ev.target.closest('[data-konfirmasi]');
    if (b && !window.confirm(b.dataset.konfirmasi)) ev.preventDefault();
  });

  // Form game: tampilkan kolom label server hanya jika dibutuhkan
  var cek = document.getElementById('butuh-server');
  var wrap = document.getElementById('wrap-server');
  if (cek && wrap) {
    var toggle = function () { wrap.hidden = !cek.checked; };
    cek.addEventListener('change', toggle);
    toggle();
  }
})();
