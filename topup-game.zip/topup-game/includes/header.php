<?php
require_once __DIR__ . '/functions.php';
$judul = $judul ?? 'Top up game';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($judul) ?> | <?= e(APP_NAME) ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@600;800&family=Plus+Jakarta+Sans:wght@400;500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
</head>
<body>
<header class="topbar">
  <div class="wrap topbar-in">
    <a class="logo" href="<?= e(url('index.php')) ?>"><span class="logo-coin">K</span><?= e(APP_NAME) ?></a>
    <nav class="nav">
      <a href="<?= e(url('index.php')) ?>">Beranda</a>
      <a href="<?= e(url('cek.php')) ?>">Cek pesanan</a>
      <a href="<?= e(url('admin/')) ?>" class="nav-admin">Admin</a>
    </nav>
  </div>
</header>
<main class="wrap">
<?php if ($f = flash()): ?>
  <div class="alert alert-<?= e($f['tipe']) ?>"><?= e($f['pesan']) ?></div>
<?php endif; ?>
