<?php
require_once __DIR__ . '/../config/config.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    }
    return $pdo;
}

function e($v): string
{
    return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
}

function rupiah($n): string
{
    return 'Rp ' . number_format((float) $n, 0, ',', '.');
}

function tanggal($dt): string
{
    return $dt ? date('d/m/Y H:i', strtotime($dt)) : '-';
}

function url(string $path = ''): string
{
    return BASE_URL . '/' . ltrim($path, '/');
}

function redirect(string $path): void
{
    header('Location: ' . $path);
    exit;
}

/* ---------- CSRF ---------- */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_check(): void
{
    $ok = isset($_POST['csrf'], $_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $_POST['csrf']);
    if (!$ok) {
        http_response_code(419);
        exit('Sesi formulir tidak valid. Muat ulang halaman lalu coba lagi.');
    }
}

/* ---------- Flash message ---------- */
function flash(?string $pesan = null, string $tipe = 'ok')
{
    if ($pesan !== null) {
        $_SESSION['flash'] = ['pesan' => $pesan, 'tipe' => $tipe];
        return null;
    }
    $f = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $f;
}

/* ---------- Auth admin ---------- */
function is_admin(): bool
{
    return !empty($_SESSION['admin_id']);
}

function require_admin(): void
{
    if (!is_admin()) {
        redirect(url('admin/login.php'));
    }
}

/* ---------- Helper transaksi ---------- */
const STATUS_LIST = ['pending', 'dibayar', 'sukses', 'gagal', 'batal'];

function status_label(string $s): string
{
    return [
        'pending' => 'Menunggu pembayaran',
        'dibayar' => 'Menunggu verifikasi',
        'sukses'  => 'Sukses',
        'gagal'   => 'Gagal',
        'batal'   => 'Dibatalkan',
    ][$s] ?? $s;
}

function status_badge(string $s): string
{
    return '<span class="badge badge-' . e($s) . '">' . e(status_label($s)) . '</span>';
}

function buat_kode(): string
{
    $huruf = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    do {
        $kode = 'KG' . date('ymd');
        for ($i = 0; $i < 4; $i++) {
            $kode .= $huruf[random_int(0, strlen($huruf) - 1)];
        }
        $cek = db()->prepare('SELECT COUNT(*) FROM transaksi WHERE kode = ?');
        $cek->execute([$kode]);
    } while ($cek->fetchColumn() > 0);
    return $kode;
}

function inisial(string $nama): string
{
    $kata = preg_split('/\s+/', trim($nama));
    $hasil = '';
    foreach (array_slice($kata, 0, 2) as $k) {
        $hasil .= mb_strtoupper(mb_substr($k, 0, 1));
    }
    return $hasil;
}
