</main>
<footer class="foot">
  <div class="wrap foot-in">
    <span><?= e(APP_NAME) ?> &mdash; proyek mata kuliah Digital Entrepreneurship</span>
    <span>Adrian Majid Saktiawan</span>
  </div>
</footer>
<script src="<?= e(url('assets/js/app.js')) ?>"></script>
</body>
</html>
