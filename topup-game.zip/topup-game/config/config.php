<?php
// Pengaturan aplikasi. Sesuaikan dengan lingkungan XAMPP/Laragon Anda.
define('DB_HOST', 'localhost');
define('DB_NAME', 'db_topup_game');
define('DB_USER', 'root');
define('DB_PASS', '');

// Nama folder proyek di htdocs (tanpa garis miring di akhir)
define('BASE_URL', '/topup-game');

define('APP_NAME', 'KiosGame');
