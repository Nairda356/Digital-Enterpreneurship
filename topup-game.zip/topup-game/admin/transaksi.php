<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $id = (int) ($_POST['id'] ?? 0);
    $status = $_POST['status'] ?? '';
    $catatan = trim($_POST['catatan'] ?? '');
    if ($id > 0 && in_array($status, STATUS_LIST, true)) {
        db()->prepare('UPDATE transaksi SET status = ?, catatan = ? WHERE id = ?')
            ->execute([$status, $catatan !== '' ? mb_substr($catatan, 0, 255) : null, $id]);
        flash('Status transaksi diperbarui.');
    }
    redirect($_SERVER['REQUEST_URI']);
}

$judul = 'Transaksi';
$halaman = 'transaksi';
require __DIR__ . '/partials/header.php';

$status = $_GET['status'] ?? '';
$q = trim($_GET['q'] ?? '');
$hal = max(1, (int) ($_GET['hal'] ?? 1));
$per = 15;

$where = [];
$par = [];
if (in_array($status, STATUS_LIST, true)) { $where[] = 't.status = ?'; $par[] = $status; }
if ($q !== '') {
    $where[] = '(t.kode LIKE ? OR t.user_game_id LIKE ? OR t.kontak LIKE ? OR t.nama_pelanggan LIKE ?)';
    array_push($par, "%$q%", "%$q%", "%$q%", "%$q%");
}
$w = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$c = db()->prepare("SELECT COUNT(*) FROM transaksi t $w");
$c->execute($par);
$total = (int) $c->fetchColumn();
$halMaks = max(1, (int) ceil($total / $per));
$hal = min($hal, $halMaks);

$sql = "SELECT t.*, g.nama game, p.nama_item, m.nama metode
          FROM transaksi t
          JOIN games g ON g.id=t.game_id JOIN produk p ON p.id=t.produk_id JOIN metode_pembayaran m ON m.id=t.metode_id
          $w ORDER BY t.id DESC LIMIT $per OFFSET " . (($hal - 1) * $per);
$st = db()->prepare($sql);
$st->execute($par);
$data = $st->fetchAll();

$qs = fn(array $x) => http_build_query(array_filter(array_merge(['status' => $status, 'q' => $q], $x), fn($v) => $v !== '' && $v !== null));
?>
<div class="page-head"><h1>Transaksi</h1><p class="muted"><?= $total ?> data</p></div>

<form class="filter card" method="get">
  <input class="input" type="search" name="q" value="<?= e($q) ?>" placeholder="Cari kode, ID game, atau nomor WA">
  <select class="input" name="status">
    <option value="">Semua status</option>
    <?php foreach (STATUS_LIST as $s): ?>
      <option value="<?= e($s) ?>" <?= $status === $s ? 'selected' : '' ?>><?= e(status_label($s)) ?></option>
    <?php endforeach; ?>
  </select>
  <button class="btn btn-primary" type="submit">Terapkan</button>
</form>

<div class="card">
  <div class="table-wrap">
    <table>
      <thead><tr><th>Kode</th><th>Pelanggan</th><th>Pesanan</th><th class="num">Total</th><th class="num">Laba</th><th>Status</th><th>Ubah status</th></tr></thead>
      <tbody>
      <?php foreach ($data as $t): ?>
        <tr>
          <td><strong><?= e($t['kode']) ?></strong><br><span class="muted small"><?= e(tanggal($t['created_at'])) ?></span></td>
          <td><?= e($t['nama_pelanggan'] ?: '-') ?><br><span class="muted small"><?= e($t['kontak']) ?></span></td>
          <td><?= e($t['game']) ?> - <?= e($t['nama_item']) ?><br>
              <span class="muted small">ID <?= e($t['user_game_id']) ?><?= $t['server_game'] ? ' (' . e($t['server_game']) . ')' : '' ?> &middot; <?= e($t['metode']) ?></span></td>
          <td class="num"><?= e(rupiah($t['total'])) ?></td>
          <td class="num"><?= e(rupiah($t['harga_jual'] - $t['harga_modal'])) ?></td>
          <td><?= status_badge($t['status']) ?></td>
          <td>
            <form method="post" class="inline-form">
              <?= csrf_field() ?>
              <input type="hidden" name="id" value="<?= (int) $t['id'] ?>">
              <select class="input input-sm" name="status" aria-label="Status baru">
                <?php foreach (STATUS_LIST as $s): ?>
                  <option value="<?= e($s) ?>" <?= $t['status'] === $s ? 'selected' : '' ?>><?= e(status_label($s)) ?></option>
                <?php endforeach; ?>
              </select>
              <input class="input input-sm" name="catatan" value="<?= e($t['catatan']) ?>" placeholder="Catatan" maxlength="255">
              <button class="btn btn-sm" type="submit">Simpan</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$data): ?><tr><td colspan="7" class="empty">Tidak ada transaksi yang cocok.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if ($halMaks > 1): ?>
  <nav class="pager" aria-label="Halaman">
    <?php for ($i = 1; $i <= $halMaks; $i++): ?>
      <a class="<?= $i === $hal ? 'on' : '' ?>" href="?<?= e($qs(['hal' => $i])) ?>"><?= $i ?></a>
    <?php endfor; ?>
  </nav>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/partials/footer.php'; ?>
