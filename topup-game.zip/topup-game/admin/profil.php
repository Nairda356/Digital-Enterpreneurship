<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $lama = $_POST['lama'] ?? '';
    $baru = $_POST['baru'] ?? '';
    $ulang = $_POST['ulang'] ?? '';

    $st = db()->prepare('SELECT password FROM admin WHERE id = ?');
    $st->execute([$_SESSION['admin_id']]);
    $hash = $st->fetchColumn();

    if (!$hash || !password_verify($lama, $hash)) {
        flash('Password lama salah.', 'err');
    } elseif (strlen($baru) < 8) {
        flash('Password baru minimal 8 karakter.', 'err');
    } elseif ($baru !== $ulang) {
        flash('Konfirmasi password tidak sama.', 'err');
    } else {
        db()->prepare('UPDATE admin SET password = ? WHERE id = ?')
            ->execute([password_hash($baru, PASSWORD_DEFAULT), $_SESSION['admin_id']]);
        flash('Password berhasil diganti.');
    }
    redirect('profil.php');
}

$judul = 'Profil';
$halaman = 'profil';
require __DIR__ . '/partials/header.php';
?>
<div class="page-head"><h1>Profil admin</h1></div>
<section class="card narrow-left">
  <h2>Ganti password</h2>
  <form method="post">
    <?= csrf_field() ?>
    <label class="field"><span>Password lama</span><input class="input" type="password" name="lama" required autocomplete="current-password"></label>
    <label class="field"><span>Password baru (minimal 8 karakter)</span><input class="input" type="password" name="baru" required minlength="8" autocomplete="new-password"></label>
    <label class="field"><span>Ulangi password baru</span><input class="input" type="password" name="ulang" required autocomplete="new-password"></label>
    <button class="btn btn-primary" type="submit">Simpan password</button>
  </form>
</section>
<?php require __DIR__ . '/partials/footer.php'; ?>
