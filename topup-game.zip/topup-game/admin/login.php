<?php
require_once __DIR__ . '/../includes/functions.php';

if (is_admin()) {
    redirect(url('admin/index.php'));
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $st = db()->prepare('SELECT * FROM admin WHERE username = ?');
    $st->execute([trim($_POST['username'] ?? '')]);
    $a = $st->fetch();
    if ($a && password_verify($_POST['password'] ?? '', $a['password'])) {
        session_regenerate_id(true);
        $_SESSION['admin_id'] = (int) $a['id'];
        $_SESSION['admin_nama'] = $a['nama'];
        redirect(url('admin/index.php'));
    }
    $error = 'Username atau password salah.';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Masuk admin | <?= e(APP_NAME) ?></title>
  <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@600;800&family=Plus+Jakarta+Sans:wght@400;500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
</head>
<body class="login-page">
  <form method="post" class="card login-card">
    <a class="logo" href="<?= e(url('index.php')) ?>"><span class="logo-coin">K</span><?= e(APP_NAME) ?></a>
    <h1>Masuk ke dashboard</h1>
    <?php if ($error): ?><div class="alert alert-err"><?= e($error) ?></div><?php endif; ?>
    <?= csrf_field() ?>
    <label class="field"><span>Username</span>
      <input class="input" name="username" required autofocus autocomplete="username"></label>
    <label class="field"><span>Password</span>
      <input class="input" type="password" name="password" required autocomplete="current-password"></label>
    <button class="btn btn-primary btn-block" type="submit">Masuk</button>
  </form>
</body>
</html>
