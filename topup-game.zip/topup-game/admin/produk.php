<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

$pdo = db();
$games = $pdo->query('SELECT id, nama FROM games ORDER BY nama')->fetchAll();
$filter = (int) ($_GET['game'] ?? 0);

$edit = null;
if (isset($_GET['edit'])) {
    $st = $pdo->prepare('SELECT * FROM produk WHERE id = ?');
    $st->execute([(int) $_GET['edit']]);
    $edit = $st->fetch() ?: null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $aksi = $_POST['aksi'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);

    if ($aksi === 'simpan') {
        $gid = (int) ($_POST['game_id'] ?? 0);
        $nama = trim($_POST['nama_item'] ?? '');
        $modal = (int) ($_POST['harga_modal'] ?? 0);
        $jual = (int) ($_POST['harga_jual'] ?? 0);
        $aktif = isset($_POST['aktif']) ? 1 : 0;
        if (!$gid || $nama === '' || $modal <= 0 || $jual <= 0) {
            flash('Game, nama item, dan harga wajib diisi.', 'err');
        } elseif ($jual < $modal) {
            flash('Harga jual lebih rendah dari harga modal. Periksa kembali agar tidak rugi.', 'err');
        } else {
            if ($id) {
                $pdo->prepare('UPDATE produk SET game_id=?, nama_item=?, harga_modal=?, harga_jual=?, aktif=? WHERE id=?')
                    ->execute([$gid, $nama, $modal, $jual, $aktif, $id]);
                flash('Produk diperbarui.');
            } else {
                $pdo->prepare('INSERT INTO produk (game_id, nama_item, harga_modal, harga_jual, aktif) VALUES (?,?,?,?,?)')
                    ->execute([$gid, $nama, $modal, $jual, $aktif]);
                flash('Produk ditambahkan.');
            }
        }
    } elseif ($aksi === 'hapus' && $id) {
        try {
            $pdo->prepare('DELETE FROM produk WHERE id = ?')->execute([$id]);
            flash('Produk dihapus.');
        } catch (PDOException $ex) {
            flash('Produk punya riwayat transaksi, jadi tidak bisa dihapus. Nonaktifkan saja.', 'err');
        }
    }
    redirect('produk.php' . ($filter ? '?game=' . $filter : ''));
}

$judul = 'Produk dan harga';
$halaman = 'produk';
require __DIR__ . '/partials/header.php';

$sql = 'SELECT p.*, g.nama game FROM produk p JOIN games g ON g.id=p.game_id' . ($filter ? ' WHERE p.game_id = ?' : '') . ' ORDER BY g.nama, p.harga_jual';
$st = $pdo->prepare($sql);
$st->execute($filter ? [$filter] : []);
$daftar = $st->fetchAll();
$f = $edit ?: ['id' => 0, 'game_id' => $filter, 'nama_item' => '', 'harga_modal' => '', 'harga_jual' => '', 'aktif' => 1];
?>
<div class="page-head"><h1>Produk dan harga</h1></div>

<section class="card">
  <h2><?= $edit ? 'Ubah produk' : 'Tambah produk' ?></h2>
  <form method="post" class="grid-form">
    <?= csrf_field() ?>
    <input type="hidden" name="aksi" value="simpan">
    <input type="hidden" name="id" value="<?= (int) $f['id'] ?>">
    <label class="field"><span>Game</span>
      <select class="input" name="game_id" required>
        <option value="">Pilih game</option>
        <?php foreach ($games as $g): ?>
          <option value="<?= (int) $g['id'] ?>" <?= $f['game_id'] == $g['id'] ? 'selected' : '' ?>><?= e($g['nama']) ?></option>
        <?php endforeach; ?>
      </select></label>
    <label class="field"><span>Nama item</span><input class="input" name="nama_item" value="<?= e($f['nama_item']) ?>" placeholder="86 Diamond" required></label>
    <label class="field"><span>Harga modal (Rp)</span><input class="input" type="number" min="1" name="harga_modal" value="<?= e($f['harga_modal']) ?>" required></label>
    <label class="field"><span>Harga jual (Rp)</span><input class="input" type="number" min="1" name="harga_jual" value="<?= e($f['harga_jual']) ?>" required></label>
    <label class="check"><input type="checkbox" name="aktif" <?= $f['aktif'] ? 'checked' : '' ?>> Dijual</label>
    <div class="actions">
      <button class="btn btn-primary" type="submit">Simpan produk</button>
      <?php if ($edit): ?><a class="btn btn-ghost" href="produk.php">Batal</a><?php endif; ?>
    </div>
  </form>
</section>

<section class="card">
  <form method="get" class="filter">
    <select class="input" name="game" aria-label="Filter game">
      <option value="">Semua game</option>
      <?php foreach ($games as $g): ?>
        <option value="<?= (int) $g['id'] ?>" <?= $filter === (int) $g['id'] ? 'selected' : '' ?>><?= e($g['nama']) ?></option>
      <?php endforeach; ?>
    </select>
    <button class="btn" type="submit">Filter</button>
  </form>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Game</th><th>Item</th><th class="num">Modal</th><th class="num">Jual</th><th class="num">Untung</th><th>Status</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($daftar as $p): $u = $p['harga_jual'] - $p['harga_modal']; ?>
        <tr>
          <td><?= e($p['game']) ?></td><td><?= e($p['nama_item']) ?></td>
          <td class="num"><?= e(rupiah($p['harga_modal'])) ?></td>
          <td class="num"><?= e(rupiah($p['harga_jual'])) ?></td>
          <td class="num"><?= e(rupiah($u)) ?> <span class="muted small">(<?= number_format($u / max(1, $p['harga_jual']) * 100, 1, ',', '.') ?>%)</span></td>
          <td><?= $p['aktif'] ? '<span class="badge badge-sukses">Dijual</span>' : '<span class="badge badge-batal">Nonaktif</span>' ?></td>
          <td class="row-actions">
            <a class="btn btn-sm" href="produk.php?edit=<?= (int) $p['id'] ?>">Ubah</a>
            <form method="post" class="inline-form">
              <?= csrf_field() ?><input type="hidden" name="aksi" value="hapus"><input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
              <button class="btn btn-sm btn-danger" type="submit" data-konfirmasi="Hapus produk <?= e($p['nama_item']) ?>?">Hapus</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$daftar): ?><tr><td colspan="7" class="empty">Belum ada produk.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</section>
<?php require __DIR__ . '/partials/footer.php'; ?>
