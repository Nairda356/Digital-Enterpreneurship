<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

$pdo = db();
$edit = null;
if (isset($_GET['edit'])) {
    $st = $pdo->prepare('SELECT * FROM games WHERE id = ?');
    $st->execute([(int) $_GET['edit']]);
    $edit = $st->fetch() ?: null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $aksi = $_POST['aksi'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);

    if ($aksi === 'simpan') {
        $nama = trim($_POST['nama'] ?? '');
        $pub = trim($_POST['publisher'] ?? '');
        $warna = $_POST['warna'] ?? '#4c3ff0';
        $labelId = trim($_POST['label_id'] ?? '') ?: 'User ID';
        $butuh = isset($_POST['butuh_server']) ? 1 : 0;
        $labelSrv = $butuh ? (trim($_POST['label_server'] ?? '') ?: 'Server') : null;
        $aktif = isset($_POST['aktif']) ? 1 : 0;

        if ($nama === '' || $pub === '' || !preg_match('/^#[0-9a-fA-F]{6}$/', $warna)) {
            flash('Nama, publisher, dan warna wajib diisi dengan benar.', 'err');
            redirect('games.php' . ($id ? '?edit=' . $id : ''));
        }
        $slug = trim(preg_replace('/[^a-z0-9]+/', '-', strtolower($nama)), '-');
        try {
            if ($id) {
                $pdo->prepare('UPDATE games SET nama=?, slug=?, publisher=?, warna=?, label_id=?, butuh_server=?, label_server=?, aktif=? WHERE id=?')
                    ->execute([$nama, $slug, $pub, $warna, $labelId, $butuh, $labelSrv, $aktif, $id]);
                flash('Game diperbarui.');
            } else {
                $pdo->prepare('INSERT INTO games (nama, slug, publisher, warna, label_id, butuh_server, label_server, aktif) VALUES (?,?,?,?,?,?,?,?)')
                    ->execute([$nama, $slug, $pub, $warna, $labelId, $butuh, $labelSrv, $aktif]);
                flash('Game ditambahkan.');
            }
        } catch (PDOException $ex) {
            flash('Nama game sudah dipakai. Gunakan nama lain.', 'err');
        }
    } elseif ($aksi === 'hapus' && $id) {
        try {
            $pdo->prepare('DELETE FROM games WHERE id = ?')->execute([$id]);
            flash('Game dihapus.');
        } catch (PDOException $ex) {
            flash('Game punya riwayat transaksi, jadi tidak bisa dihapus. Nonaktifkan saja.', 'err');
        }
    }
    redirect('games.php');
}

$judul = 'Game';
$halaman = 'games';
require __DIR__ . '/partials/header.php';

$daftar = $pdo->query('SELECT g.*, (SELECT COUNT(*) FROM produk p WHERE p.game_id=g.id) jml_produk,
                              (SELECT COUNT(*) FROM transaksi t WHERE t.game_id=g.id) jml_trx
                         FROM games g ORDER BY g.nama')->fetchAll();
$f = $edit ?: ['id' => 0, 'nama' => '', 'publisher' => '', 'warna' => '#4c3ff0', 'label_id' => 'User ID',
               'butuh_server' => 0, 'label_server' => '', 'aktif' => 1];
?>
<div class="page-head"><h1>Game</h1></div>

<section class="card">
  <h2><?= $edit ? 'Ubah game' : 'Tambah game' ?></h2>
  <form method="post" class="grid-form">
    <?= csrf_field() ?>
    <input type="hidden" name="aksi" value="simpan">
    <input type="hidden" name="id" value="<?= (int) $f['id'] ?>">
    <label class="field"><span>Nama game</span><input class="input" name="nama" value="<?= e($f['nama']) ?>" required></label>
    <label class="field"><span>Publisher</span><input class="input" name="publisher" value="<?= e($f['publisher']) ?>" required></label>
    <label class="field"><span>Warna ubin</span><input class="input input-color" type="color" name="warna" value="<?= e($f['warna']) ?>"></label>
    <label class="field"><span>Label ID akun</span><input class="input" name="label_id" value="<?= e($f['label_id']) ?>" placeholder="User ID"></label>
    <label class="check"><input type="checkbox" name="butuh_server" id="butuh-server" <?= $f['butuh_server'] ? 'checked' : '' ?>> Butuh server atau zone</label>
    <label class="field" id="wrap-server"><span>Label server</span><input class="input" name="label_server" value="<?= e($f['label_server']) ?>" placeholder="Zone ID"></label>
    <label class="check"><input type="checkbox" name="aktif" <?= $f['aktif'] ? 'checked' : '' ?>> Tampil di toko</label>
    <div class="actions">
      <button class="btn btn-primary" type="submit">Simpan game</button>
      <?php if ($edit): ?><a class="btn btn-ghost" href="games.php">Batal</a><?php endif; ?>
    </div>
  </form>
</section>

<section class="card">
  <div class="table-wrap">
    <table>
      <thead><tr><th>Game</th><th>Publisher</th><th class="num">Item</th><th class="num">Transaksi</th><th>Status</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($daftar as $g): ?>
        <tr>
          <td><span class="dot" style="--warna: <?= e($g['warna']) ?>"></span> <?= e($g['nama']) ?></td>
          <td><?= e($g['publisher']) ?></td>
          <td class="num"><?= (int) $g['jml_produk'] ?></td>
          <td class="num"><?= (int) $g['jml_trx'] ?></td>
          <td><?= $g['aktif'] ? '<span class="badge badge-sukses">Tampil</span>' : '<span class="badge badge-batal">Disembunyikan</span>' ?></td>
          <td class="row-actions">
            <a class="btn btn-sm" href="games.php?edit=<?= (int) $g['id'] ?>">Ubah</a>
            <form method="post" class="inline-form">
              <?= csrf_field() ?><input type="hidden" name="aksi" value="hapus"><input type="hidden" name="id" value="<?= (int) $g['id'] ?>">
              <button class="btn btn-sm btn-danger" type="submit" data-konfirmasi="Hapus game <?= e($g['nama']) ?> beserta semua itemnya?">Hapus</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</section>
<?php require __DIR__ . '/partials/footer.php'; ?>
