<?php
require_once __DIR__ . '/../../includes/functions.php';
require_admin();
$halaman = $halaman ?? '';
$menu = [
    'dashboard' => ['index.php', 'Dashboard'],
    'transaksi' => ['transaksi.php', 'Transaksi'],
    'games'     => ['games.php', 'Game'],
    'produk'    => ['produk.php', 'Produk dan harga'],
    'laporan'   => ['laporan.php', 'Laporan'],
    'profil'    => ['profil.php', 'Profil'],
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($judul ?? 'Admin') ?> | Admin <?= e(APP_NAME) ?></title>
  <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@600;800&family=Plus+Jakarta+Sans:wght@400;500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
</head>
<body class="admin">
<aside class="side">
  <a class="logo logo-light" href="<?= e(url('admin/index.php')) ?>"><span class="logo-coin">K</span><?= e(APP_NAME) ?></a>
  <nav>
    <?php foreach ($menu as $k => [$file, $label]): ?>
      <a href="<?= e(url('admin/' . $file)) ?>" class="<?= $halaman === $k ? 'active' : '' ?>"><?= e($label) ?></a>
    <?php endforeach; ?>
  </nav>
  <div class="side-foot">
    <span><?= e($_SESSION['admin_nama'] ?? '') ?></span>
    <a href="<?= e(url('index.php')) ?>" target="_blank" rel="noopener">Lihat toko</a>
    <a href="<?= e(url('admin/logout.php')) ?>">Keluar</a>
  </div>
</aside>
<div class="admin-main">
  <?php if ($f = flash()): ?><div class="alert alert-<?= e($f['tipe']) ?>"><?= e($f['pesan']) ?></div><?php endif; ?>
