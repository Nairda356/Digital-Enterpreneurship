<?php
require_once __DIR__ . '/../includes/functions.php';
require_admin();

$dari = $_GET['dari'] ?? date('Y-m-01');
$sampai = $_GET['sampai'] ?? date('Y-m-d');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dari)) { $dari = date('Y-m-01'); }
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $sampai)) { $sampai = date('Y-m-d'); }
if ($dari > $sampai) { [$dari, $sampai] = [$sampai, $dari]; }
$par = [$dari, $sampai];
$rentang = "t.created_at >= ? AND t.created_at < DATE_ADD(?, INTERVAL 1 DAY)";

// Ekspor CSV (harus sebelum ada output HTML)
if (($_GET['export'] ?? '') === 'csv') {
    $st = db()->prepare("SELECT t.kode, t.created_at, g.nama game, p.nama_item, t.user_game_id, t.kontak,
                                m.nama metode, t.harga_modal, t.harga_jual, t.biaya_admin, t.total, t.status
                           FROM transaksi t JOIN games g ON g.id=t.game_id JOIN produk p ON p.id=t.produk_id
                           JOIN metode_pembayaran m ON m.id=t.metode_id
                          WHERE $rentang ORDER BY t.created_at");
    $st->execute($par);
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="laporan-' . $dari . '_' . $sampai . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, ['Kode', 'Waktu', 'Game', 'Item', 'ID Game', 'Kontak', 'Metode', 'Modal', 'Jual', 'Biaya admin', 'Total', 'Status']);
    foreach ($st as $r) { fputcsv($out, array_values($r)); }
    exit;
}

$judul = 'Laporan';
$halaman = 'laporan';
require __DIR__ . '/partials/header.php';
$pdo = db();

$st = $pdo->prepare("SELECT COUNT(*) semua,
        SUM(status='sukses') sukses, SUM(status IN ('gagal','batal')) gagal,
        COALESCE(SUM(CASE WHEN status='sukses' THEN harga_jual END),0) omzet,
        COALESCE(SUM(CASE WHEN status='sukses' THEN harga_modal END),0) modal
      FROM transaksi t WHERE $rentang");
$st->execute($par);
$r = $st->fetch();
$laba = $r['omzet'] - $r['modal'];

$st = $pdo->prepare("SELECT g.nama, COUNT(*) jml, SUM(t.harga_jual) omzet, SUM(t.harga_jual-t.harga_modal) laba
                       FROM transaksi t JOIN games g ON g.id=t.game_id
                      WHERE t.status='sukses' AND $rentang GROUP BY g.id ORDER BY omzet DESC");
$st->execute($par);
$perGame = $st->fetchAll();

$st = $pdo->prepare("SELECT m.nama, COUNT(*) jml, SUM(t.harga_jual) omzet
                       FROM transaksi t JOIN metode_pembayaran m ON m.id=t.metode_id
                      WHERE t.status='sukses' AND $rentang GROUP BY m.id ORDER BY omzet DESC");
$st->execute($par);
$perMetode = $st->fetchAll();

$st = $pdo->prepare("SELECT DATE(t.created_at) tgl, COUNT(*) jml, SUM(t.harga_jual) omzet, SUM(t.harga_jual-t.harga_modal) laba
                       FROM transaksi t WHERE t.status='sukses' AND $rentang GROUP BY DATE(t.created_at) ORDER BY tgl DESC");
$st->execute($par);
$perHari = $st->fetchAll();
?>
<div class="page-head">
  <h1>Laporan penjualan</h1>
  <div class="actions no-print">
    <a class="btn" href="?dari=<?= e($dari) ?>&sampai=<?= e($sampai) ?>&export=csv">Unduh CSV</a>
    <button class="btn" type="button" onclick="window.print()">Cetak</button>
  </div>
</div>

<form method="get" class="filter card no-print">
  <label class="field inline"><span>Dari</span><input class="input" type="date" name="dari" value="<?= e($dari) ?>"></label>
  <label class="field inline"><span>Sampai</span><input class="input" type="date" name="sampai" value="<?= e($sampai) ?>"></label>
  <button class="btn btn-primary" type="submit">Tampilkan</button>
</form>
<p class="muted">Periode <?= e(date('d/m/Y', strtotime($dari))) ?> sampai <?= e(date('d/m/Y', strtotime($sampai))) ?>. Omzet dan laba hanya menghitung transaksi sukses.</p>

<div class="stats">
  <div class="stat"><span>Omzet</span><strong><?= e(rupiah($r['omzet'])) ?></strong><small><?= (int) $r['sukses'] ?> transaksi sukses</small></div>
  <div class="stat"><span>Modal terpakai</span><strong><?= e(rupiah($r['modal'])) ?></strong><small>dari harga modal item</small></div>
  <div class="stat stat-accent"><span>Laba kotor</span><strong><?= e(rupiah($laba)) ?></strong>
    <small>Margin <?= $r['omzet'] > 0 ? number_format($laba / $r['omzet'] * 100, 1, ',', '.') : '0' ?>%</small></div>
  <div class="stat"><span>Tingkat keberhasilan</span>
    <strong><?= $r['semua'] > 0 ? number_format($r['sukses'] / $r['semua'] * 100, 1, ',', '.') : '0' ?>%</strong>
    <small><?= (int) $r['semua'] ?> pesanan, <?= (int) $r['gagal'] ?> gagal atau batal</small></div>
</div>

<div class="cols">
  <section class="card">
    <h2>Per game</h2>
    <div class="table-wrap"><table>
      <thead><tr><th>Game</th><th class="num">Pesanan</th><th class="num">Omzet</th><th class="num">Laba</th></tr></thead>
      <tbody>
      <?php foreach ($perGame as $x): ?>
        <tr><td><?= e($x['nama']) ?></td><td class="num"><?= (int) $x['jml'] ?></td>
            <td class="num"><?= e(rupiah($x['omzet'])) ?></td><td class="num"><?= e(rupiah($x['laba'])) ?></td></tr>
      <?php endforeach; ?>
      <?php if (!$perGame): ?><tr><td colspan="4" class="empty">Tidak ada data.</td></tr><?php endif; ?>
      </tbody></table></div>
  </section>
  <section class="card">
    <h2>Per metode pembayaran</h2>
    <div class="table-wrap"><table>
      <thead><tr><th>Metode</th><th class="num">Pesanan</th><th class="num">Omzet</th></tr></thead>
      <tbody>
      <?php foreach ($perMetode as $x): ?>
        <tr><td><?= e($x['nama']) ?></td><td class="num"><?= (int) $x['jml'] ?></td><td class="num"><?= e(rupiah($x['omzet'])) ?></td></tr>
      <?php endforeach; ?>
      <?php if (!$perMetode): ?><tr><td colspan="3" class="empty">Tidak ada data.</td></tr><?php endif; ?>
      </tbody></table></div>
  </section>
</div>

<section class="card">
  <h2>Per hari</h2>
  <div class="table-wrap"><table>
    <thead><tr><th>Tanggal</th><th class="num">Pesanan</th><th class="num">Omzet</th><th class="num">Laba</th></tr></thead>
    <tbody>
    <?php foreach ($perHari as $x): ?>
      <tr><td><?= e(date('d/m/Y', strtotime($x['tgl']))) ?></td><td class="num"><?= (int) $x['jml'] ?></td>
          <td class="num"><?= e(rupiah($x['omzet'])) ?></td><td class="num"><?= e(rupiah($x['laba'])) ?></td></tr>
    <?php endforeach; ?>
    <?php if (!$perHari): ?><tr><td colspan="4" class="empty">Tidak ada data.</td></tr><?php endif; ?>
    </tbody></table></div>
</section>
<?php require __DIR__ . '/partials/footer.php'; ?>
