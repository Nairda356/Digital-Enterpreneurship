<?php
$judul = 'Dashboard';
$halaman = 'dashboard';
require __DIR__ . '/partials/header.php';

$pdo = db();
// Omzet = total harga_jual transaksi berstatus sukses. Laba = harga_jual - harga_modal.
$hariIni = $pdo->query("SELECT COALESCE(SUM(harga_jual),0) omzet, COUNT(*) jml
                          FROM transaksi WHERE status='sukses' AND DATE(created_at)=CURDATE()")->fetch();
$bulanIni = $pdo->query("SELECT COALESCE(SUM(harga_jual),0) omzet, COALESCE(SUM(harga_jual-harga_modal),0) laba, COUNT(*) jml
                           FROM transaksi WHERE status='sukses'
                            AND YEAR(created_at)=YEAR(CURDATE()) AND MONTH(created_at)=MONTH(CURDATE())")->fetch();
$perluAksi = $pdo->query("SELECT
        SUM(status='pending') pending, SUM(status='dibayar') dibayar FROM transaksi")->fetch();

// Omzet 14 hari terakhir
$rows = $pdo->query("SELECT DATE(created_at) tgl, SUM(harga_jual) omzet
                       FROM transaksi
                      WHERE status='sukses' AND created_at >= CURDATE() - INTERVAL 13 DAY
                      GROUP BY DATE(created_at)")->fetchAll(PDO::FETCH_KEY_PAIR);
$grafik = [];
for ($i = 13; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i day"));
    $grafik[] = ['tgl' => $d, 'omzet' => (int) ($rows[$d] ?? 0)];
}
$maks = max(1, max(array_column($grafik, 'omzet')));

$topGame = $pdo->query("SELECT g.nama, g.warna, COUNT(*) jml, SUM(t.harga_jual) omzet
                          FROM transaksi t JOIN games g ON g.id=t.game_id
                         WHERE t.status='sukses'
                         GROUP BY g.id ORDER BY omzet DESC LIMIT 5")->fetchAll();

$terbaru = $pdo->query("SELECT t.kode, t.total, t.status, t.created_at, g.nama game, p.nama_item
                          FROM transaksi t JOIN games g ON g.id=t.game_id JOIN produk p ON p.id=t.produk_id
                         ORDER BY t.id DESC LIMIT 8")->fetchAll();
?>
<div class="page-head"><h1>Dashboard</h1><p class="muted"><?= e(date('d/m/Y')) ?></p></div>

<div class="stats">
  <div class="stat"><span>Omzet hari ini</span><strong><?= e(rupiah($hariIni['omzet'])) ?></strong><small><?= (int) $hariIni['jml'] ?> pesanan sukses</small></div>
  <div class="stat"><span>Omzet bulan ini</span><strong><?= e(rupiah($bulanIni['omzet'])) ?></strong><small><?= (int) $bulanIni['jml'] ?> pesanan sukses</small></div>
  <div class="stat stat-accent"><span>Laba bulan ini</span><strong><?= e(rupiah($bulanIni['laba'])) ?></strong>
    <small>Margin <?= $bulanIni['omzet'] > 0 ? number_format($bulanIni['laba'] / $bulanIni['omzet'] * 100, 1, ',', '.') : '0' ?>%</small></div>
  <a class="stat stat-link" href="transaksi.php?status=dibayar"><span>Perlu tindakan</span>
    <strong><?= (int) $perluAksi['dibayar'] ?> menunggu verifikasi</strong><small><?= (int) $perluAksi['pending'] ?> belum bayar</small></a>
</div>

<div class="cols">
  <section class="card">
    <h2>Omzet 14 hari terakhir</h2>
    <div class="bars" role="img" aria-label="Grafik batang omzet 14 hari terakhir">
      <?php foreach ($grafik as $g): ?>
        <div class="bar" title="<?= e(date('d/m', strtotime($g['tgl'])) . ': ' . rupiah($g['omzet'])) ?>">
          <span class="bar-fill" style="height: <?= round($g['omzet'] / $maks * 100) ?>%"></span>
          <span class="bar-x"><?= e(date('d', strtotime($g['tgl']))) ?></span>
        </div>
      <?php endforeach; ?>
    </div>
    <p class="muted small">Tertinggi dalam periode: <?= e(rupiah($maks > 1 ? $maks : 0)) ?> per hari.</p>
  </section>

  <section class="card">
    <h2>Game terlaris</h2>
    <?php if (!$topGame): ?><p class="empty">Belum ada transaksi sukses.</p><?php endif; ?>
    <ul class="rank">
      <?php foreach ($topGame as $g): ?>
        <li style="--warna: <?= e($g['warna']) ?>">
          <span class="dot"></span><span class="rank-name"><?= e($g['nama']) ?></span>
          <span class="muted"><?= (int) $g['jml'] ?> pesanan</span><strong><?= e(rupiah($g['omzet'])) ?></strong>
        </li>
      <?php endforeach; ?>
    </ul>
  </section>
</div>

<section class="card">
  <div class="section-head"><h2>Transaksi terbaru</h2><a href="transaksi.php">Lihat semua</a></div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Kode</th><th>Game</th><th>Item</th><th class="num">Total</th><th>Status</th><th>Waktu</th></tr></thead>
      <tbody>
      <?php foreach ($terbaru as $t): ?>
        <tr>
          <td><a href="<?= e(url('invoice.php?kode=' . $t['kode'])) ?>" target="_blank" rel="noopener"><?= e($t['kode']) ?></a></td>
          <td><?= e($t['game']) ?></td><td><?= e($t['nama_item']) ?></td>
          <td class="num"><?= e(rupiah($t['total'])) ?></td>
          <td><?= status_badge($t['status']) ?></td><td><?= e(tanggal($t['created_at'])) ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$terbaru): ?><tr><td colspan="6" class="empty">Belum ada transaksi.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</section>
<?php require __DIR__ . '/partials/footer.php'; ?>
